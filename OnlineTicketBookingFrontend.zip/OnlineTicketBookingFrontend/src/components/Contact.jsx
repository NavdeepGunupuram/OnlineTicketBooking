const Contact = () => (
  <div style={{ padding: 40, color: "#00bfa5", fontSize: 32 }}>
    Contact Page Coming Soon!
  </div>
);
export default Contact;
