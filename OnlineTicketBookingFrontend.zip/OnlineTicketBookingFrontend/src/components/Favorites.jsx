const Favorites = () => (
  <div style={{ padding: 40, color: "#26a69a", fontSize: 32 }}>
    Favorites Page Coming Soon!
  </div>
);
export default Favorites;
